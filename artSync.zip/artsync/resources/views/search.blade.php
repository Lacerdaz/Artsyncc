<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-black leading-tight">
                Busca Avançada
            </h2>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Search Bar -->
            <div class="bg-white border-2 border-black rounded-lg p-6 mb-8">
                <div class="flex space-x-4">
                    <div class="flex-1">
                        <input type="text" 
                               class="w-full border-2 border-black rounded-lg p-4 text-lg" 
                               placeholder="Buscar projetos, arquivos, contatos, contratos..."
                               value="arte digital">
                    </div>
                    <button class="bg-black text-white px-8 py-4 rounded-lg hover:bg-gray-800 transition-colors">
                        🔍 Buscar
                    </button>
                </div>

                <!-- Advanced Filters -->
                <div class="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Tipo</label>
                        <select class="w-full border-2 border-black rounded-lg p-2">
                            <option>Todos os tipos</option>
                            <option>Projetos</option>
                            <option>Arquivos</option>
                            <option>Contratos</option>
                            <option>Contatos</option>
                            <option>Notificações</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Data</label>
                        <select class="w-full border-2 border-black rounded-lg p-2">
                            <option>Qualquer data</option>
                            <option>Última semana</option>
                            <option>Último mês</option>
                            <option>Últimos 3 meses</option>
                            <option>Último ano</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Status</label>
                        <select class="w-full border-2 border-black rounded-lg p-2">
                            <option>Todos os status</option>
                            <option>Em andamento</option>
                            <option>Concluído</option>
                            <option>Pausado</option>
                            <option>Cancelado</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Categoria</label>
                        <select class="w-full border-2 border-black rounded-lg p-2">
                            <option>Todas as categorias</option>
                            <option>Ilustração</option>
                            <option>Design Gráfico</option>
                            <option>Fotografia</option>
                            <option>Arte Digital</option>
                            <option>Branding</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Search Results -->
            <div class="bg-white border-2 border-black rounded-lg overflow-hidden">
                <!-- Results Header -->
                <div class="bg-gray-50 border-b border-black p-4 flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-black">Resultados da Busca</h3>
                        <p class="text-sm text-gray-600">8 resultados encontrados para "arte digital"</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="text-sm border border-black px-3 py-1 rounded hover:bg-black hover:text-white">
                            Relevância
                        </button>
                        <button class="text-sm border border-black px-3 py-1 rounded hover:bg-black hover:text-white">
                            Data
                        </button>
                        <button class="text-sm border border-black px-3 py-1 rounded hover:bg-black hover:text-white">
                            Nome
                        </button>
                    </div>
                </div>

                <!-- Results List -->
                <div class="divide-y divide-gray-200">
                    <!-- Project Result -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center">
                                <span class="text-blue-600 text-2xl">🎨</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-lg font-semibold text-black">Projeto Arte Digital Corporativa</h4>
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">PROJETO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Criação de arte digital para campanha publicitária da empresa TechCorp. Inclui ilustrações vetoriais e composições digitais.
                            </p>
                            <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>📅 Criado em 15/01/2025</span>
                                <span>👤 Cliente: TechCorp</span>
                                <span>💰 R$ 3.500,00</span>
                                <span>⏱️ Em andamento</span>
                            </div>
                        </div>
                        <button class="text-black hover:text-gray-600 p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- File Result -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center">
                                <span class="text-red-600 text-2xl">📄</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-lg font-semibold text-black">arte_digital_final.psd</h4>
                                <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">ARQUIVO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Arquivo principal do projeto de arte digital. Contém todas as camadas e elementos da composição final.
                            </p>
                            <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>📅 Modificado em 20/01/2025</span>
                                <span>📁 Pasta: Projetos 2025</span>
                                <span>💾 45.2 MB</span>
                                <span>🎨 Photoshop</span>
                            </div>
                        </div>
                        <button class="text-black hover:text-gray-600 p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Contract Result -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-yellow-100 rounded-lg flex items-center justify-center">
                                <span class="text-yellow-600 text-2xl">📋</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-lg font-semibold text-black">Contrato - Arte Digital TechCorp</h4>
                                <span class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">CONTRATO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Contrato de prestação de serviços para criação de arte digital corporativa. Inclui direitos autorais e prazos de entrega.
                            </p>
                            <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>📅 Assinado em 10/01/2025</span>
                                <span>👤 TechCorp Ltda</span>
                                <span>💰 R$ 3.500,00</span>
                                <span>✅ Ativo</span>
                            </div>
                        </div>
                        <button class="text-black hover:text-gray-600 p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Contact Result -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center">
                                <span class="text-purple-600 text-2xl">👤</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-lg font-semibold text-black">Carlos Silva - Diretor de Arte</h4>
                                <span class="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">CONTATO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Diretor de arte da TechCorp, responsável pela aprovação de projetos de arte digital e campanhas visuais.
                            </p>
                            <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>📧 carlos@techcorp.com</span>
                                <span>📱 (11) 99999-9999</span>
                                <span>🏢 TechCorp</span>
                                <span>⭐ Cliente VIP</span>
                            </div>
                        </div>
                        <button class="text-black hover:text-gray-600 p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Portfolio Item Result -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                                <span class="text-green-600 text-2xl">🖼️</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-lg font-semibold text-black">Arte Digital - Série Futurista</h4>
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">PORTFÓLIO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Coleção de artes digitais com temática futurista, criadas usando técnicas de pintura digital e composição 3D.
                            </p>
                            <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                <span>📅 Adicionado em 05/01/2025</span>
                                <span>👁️ 1.234 visualizações</span>
                                <span>❤️ 89 curtidas</span>
                                <span>🏷️ Arte Digital, Futurismo</span>
                            </div>
                        </div>
                        <button class="text-black hover:text-gray-600 p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Pagination -->
                <div class="p-4 border-t border-gray-200 flex items-center justify-between">
                    <div class="text-sm text-gray-600">
                        Mostrando 1-5 de 8 resultados
                    </div>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 border border-black rounded hover:bg-black hover:text-white">
                            Anterior
                        </button>
                        <button class="px-3 py-1 bg-black text-white rounded">
                            1
                        </button>
                        <button class="px-3 py-1 border border-black rounded hover:bg-black hover:text-white">
                            2
                        </button>
                        <button class="px-3 py-1 border border-black rounded hover:bg-black hover:text-white">
                            Próximo
                        </button>
                    </div>
                </div>
            </div>

            <!-- Quick Search Suggestions -->
            <div class="mt-8">
                <h3 class="text-lg font-semibold text-black mb-4">Buscas Sugeridas</h3>
                <div class="flex flex-wrap gap-2">
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        projetos em andamento
                    </button>
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        contratos 2025
                    </button>
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        arquivos PSD
                    </button>
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        clientes VIP
                    </button>
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        ilustrações
                    </button>
                    <button class="bg-white border-2 border-black px-4 py-2 rounded-lg hover:bg-black hover:text-white transition-all">
                        pagamentos pendentes
                    </button>
                </div>
            </div>

            <!-- Search Statistics -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">156</div>
                    <div class="text-sm text-gray-600">Total de Itens</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">45</div>
                    <div class="text-sm text-gray-600">Projetos</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">89</div>
                    <div class="text-sm text-gray-600">Arquivos</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">22</div>
                    <div class="text-sm text-gray-600">Contratos</div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

