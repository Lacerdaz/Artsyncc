<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-black leading-tight">
                Notificações
            </h2>
            <button class="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
                + Nova Notificação
            </button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Notification Stats -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">12</div>
                    <div class="text-sm text-gray-600">Não Lidas</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">3</div>
                    <div class="text-sm text-gray-600">Urgentes</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">8</div>
                    <div class="text-sm text-gray-600">Lembretes</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">25</div>
                    <div class="text-sm text-gray-600">Total</div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">⏰</div>
                    <div class="font-semibold">Criar Lembrete</div>
                </button>
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">📅</div>
                    <div class="font-semibold">Agendar Evento</div>
                </button>
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">🔔</div>
                    <div class="font-semibold">Configurar Alertas</div>
                </button>
            </div>

            <!-- Notifications List -->
            <div class="bg-white border-2 border-black rounded-lg overflow-hidden">
                <!-- Header -->
                <div class="bg-gray-50 border-b border-black p-4 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-black">Todas as Notificações</h3>
                    <div class="flex space-x-2">
                        <button class="text-sm bg-black text-white px-3 py-1 rounded hover:bg-gray-800">
                            Marcar todas como lidas
                        </button>
                        <button class="text-sm border border-black px-3 py-1 rounded hover:bg-black hover:text-white">
                            Filtrar
                        </button>
                    </div>
                </div>

                <!-- Notification Items -->
                <div class="divide-y divide-gray-200">
                    <!-- Urgent Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4 border-l-4 border-red-500">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                                <span class="text-red-600 text-lg">⚠️</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Prazo de Entrega Próximo</p>
                                <span class="text-xs text-red-600 font-semibold">URGENTE</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                O projeto "Arte Digital Corporativa" deve ser entregue em 2 dias. Verifique o progresso.
                            </p>
                            <p class="text-xs text-gray-500 mt-2">Há 1 hora</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Regular Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <span class="text-blue-600 text-lg">💼</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Nova Oportunidade de Trabalho</p>
                                <span class="text-xs text-gray-500">Não lida</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Uma nova proposta de trabalho foi recebida para ilustração de livro infantil.
                            </p>
                            <p class="text-xs text-gray-500 mt-2">Há 3 horas</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Reminder Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4 border-l-4 border-yellow-500">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                                <span class="text-yellow-600 text-lg">⏰</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Lembrete: Reunião com Cliente</p>
                                <span class="text-xs text-yellow-600 font-semibold">LEMBRETE</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Reunião agendada para apresentação do portfólio às 14:00.
                            </p>
                            <p class="text-xs text-gray-500 mt-2">Amanhã às 14:00</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Success Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4 border-l-4 border-green-500">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                                <span class="text-green-600 text-lg">✅</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Projeto Aprovado</p>
                                <span class="text-xs text-green-600 font-semibold">SUCESSO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                O projeto "Identidade Visual Café" foi aprovado pelo cliente. Parabéns!
                            </p>
                            <p class="text-xs text-gray-500 mt-2">Ontem às 16:30</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Info Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                                <span class="text-gray-600 text-lg">ℹ️</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Backup Automático Concluído</p>
                                <span class="text-xs text-gray-500">Lida</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Seus arquivos foram salvos automaticamente na nuvem.
                            </p>
                            <p class="text-xs text-gray-500 mt-2">2 dias atrás</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Payment Notification -->
                    <div class="p-4 hover:bg-gray-50 flex items-start space-x-4 border-l-4 border-blue-500">
                        <div class="flex-shrink-0">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <span class="text-blue-600 text-lg">💰</span>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-semibold text-black">Pagamento Recebido</p>
                                <span class="text-xs text-blue-600 font-semibold">FINANCEIRO</span>
                            </div>
                            <p class="text-sm text-gray-600 mt-1">
                                Pagamento de R$ 2.500,00 referente ao projeto "Logo Empresa Tech" foi recebido.
                            </p>
                            <p class="text-xs text-gray-500 mt-2">3 dias atrás</p>
                        </div>
                        <button class="text-gray-400 hover:text-black">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Load More -->
                <div class="p-4 text-center border-t border-gray-200">
                    <button class="text-black hover:text-gray-600 font-semibold">
                        Carregar mais notificações
                    </button>
                </div>
            </div>

            <!-- Notification Settings -->
            <div class="mt-8 bg-white border-2 border-black rounded-lg p-6">
                <h3 class="text-xl font-semibold text-black mb-4">Configurações de Notificação</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="font-semibold mb-3">Tipos de Notificação</h4>
                        <div class="space-y-3">
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Prazos de projetos</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Novas oportunidades</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Atualizações do sistema</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Pagamentos recebidos</span>
                            </label>
                        </div>
                    </div>
                    <div>
                        <h4 class="font-semibold mb-3">Métodos de Entrega</h4>
                        <div class="space-y-3">
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Notificações no app</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Email</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">SMS</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Push notifications</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="mt-6">
                    <button class="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                        Salvar Configurações
                    </button>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

