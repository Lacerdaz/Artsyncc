<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-black leading-tight">
                Pasta Pessoal
            </h2>
            <button class="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
                + Novo Arquivo
            </button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Storage Overview -->
            <div class="bg-white border-2 border-black rounded-lg p-6 mb-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-semibold text-black">Armazenamento</h3>
                    <span class="text-sm text-gray-600">2.3 GB de 10 GB utilizados</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-3">
                    <div class="bg-black h-3 rounded-full" style="width: 23%"></div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">📁</div>
                    <div class="font-semibold">Nova Pasta</div>
                </button>
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">📤</div>
                    <div class="font-semibold">Upload</div>
                </button>
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">📋</div>
                    <div class="font-semibold">Contratos</div>
                </button>
                <button class="bg-white border-2 border-black p-4 rounded-lg hover:bg-black hover:text-white transition-all text-center">
                    <div class="text-2xl mb-2">🎨</div>
                    <div class="font-semibold">Portfólio</div>
                </button>
            </div>

            <!-- File Browser -->
            <div class="bg-white border-2 border-black rounded-lg overflow-hidden">
                <!-- Toolbar -->
                <div class="bg-gray-50 border-b border-black p-4 flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <button class="text-black hover:text-gray-600">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                            </svg>
                        </button>
                        <span class="text-sm text-gray-600">/ Meus Arquivos</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button class="p-2 hover:bg-gray-200 rounded">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
                            </svg>
                        </button>
                        <button class="p-2 hover:bg-gray-200 rounded">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- File List -->
                <div class="p-4">
                    <!-- Folders -->
                    <div class="space-y-2 mb-4">
                        <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                            <div class="text-2xl mr-3">📁</div>
                            <div class="flex-1">
                                <p class="font-semibold">Projetos 2025</p>
                                <p class="text-sm text-gray-600">12 itens • Modificado há 2 dias</p>
                            </div>
                            <button class="text-gray-400 hover:text-black">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                </svg>
                            </button>
                        </div>

                        <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                            <div class="text-2xl mr-3">📁</div>
                            <div class="flex-1">
                                <p class="font-semibold">Contratos</p>
                                <p class="text-sm text-gray-600">5 itens • Modificado há 1 semana</p>
                            </div>
                            <button class="text-gray-400 hover:text-black">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                </svg>
                            </button>
                        </div>

                        <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                            <div class="text-2xl mr-3">📁</div>
                            <div class="flex-1">
                                <p class="font-semibold">Portfólio</p>
                                <p class="text-sm text-gray-600">28 itens • Modificado ontem</p>
                            </div>
                            <button class="text-gray-400 hover:text-black">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <!-- Files -->
                    <div class="border-t border-gray-200 pt-4">
                        <div class="space-y-2">
                            <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                                <div class="text-2xl mr-3">🖼️</div>
                                <div class="flex-1">
                                    <p class="font-semibold">arte_digital_final.psd</p>
                                    <p class="text-sm text-gray-600">45.2 MB • Modificado há 3 horas</p>
                                </div>
                                <button class="text-gray-400 hover:text-black">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                    </svg>
                                </button>
                            </div>

                            <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                                <div class="text-2xl mr-3">📄</div>
                                <div class="flex-1">
                                    <p class="font-semibold">contrato_cliente_janeiro.pdf</p>
                                    <p class="text-sm text-gray-600">2.1 MB • Modificado há 1 dia</p>
                                </div>
                                <button class="text-gray-400 hover:text-black">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                    </svg>
                                </button>
                            </div>

                            <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                                <div class="text-2xl mr-3">📸</div>
                                <div class="flex-1">
                                    <p class="font-semibold">sessao_fotos_estudio.zip</p>
                                    <p class="text-sm text-gray-600">156.8 MB • Modificado há 2 dias</p>
                                </div>
                                <button class="text-gray-400 hover:text-black">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                    </svg>
                                </button>
                            </div>

                            <div class="flex items-center p-3 hover:bg-gray-50 rounded cursor-pointer">
                                <div class="text-2xl mr-3">🎵</div>
                                <div class="flex-1">
                                    <p class="font-semibold">trilha_sonora_projeto.mp3</p>
                                    <p class="text-sm text-gray-600">8.5 MB • Modificado há 1 semana</p>
                                </div>
                                <button class="text-gray-400 hover:text-black">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="mt-6 bg-white border-2 border-black rounded-lg p-6">
                <h3 class="text-xl font-semibold text-black mb-4">Atividade Recente</h3>
                <div class="space-y-3">
                    <div class="flex items-center p-3 bg-gray-50 rounded">
                        <div class="text-sm text-gray-600">
                            <span class="font-semibold">arte_digital_final.psd</span> foi modificado há 3 horas
                        </div>
                    </div>
                    <div class="flex items-center p-3 bg-gray-50 rounded">
                        <div class="text-sm text-gray-600">
                            <span class="font-semibold">contrato_cliente_janeiro.pdf</span> foi adicionado há 1 dia
                        </div>
                    </div>
                    <div class="flex items-center p-3 bg-gray-50 rounded">
                        <div class="text-sm text-gray-600">
                            Pasta <span class="font-semibold">Projetos 2025</span> foi criada há 2 dias
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

