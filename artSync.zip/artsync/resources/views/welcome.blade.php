<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>ArtSync - Gerencie sua Carreira Artística</title>
        
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        
        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        
        <style>
            body {
                background-color: #ffffff;
                color: #000000;
                font-family: 'Figtree', sans-serif;
            }
            .bg-primary {
                background-color: #000000;
            }
            .text-primary {
                color: #000000;
            }
            .text-secondary {
                color: #ffffff;
            }
            .btn-primary {
                background-color: #000000;
                color: #ffffff;
                padding: 12px 24px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 500;
                transition: all 0.3s ease;
                border: 2px solid #000000;
            }
            .btn-primary:hover {
                background-color: #ffffff;
                color: #000000;
            }
            .btn-secondary {
                background-color: #ffffff;
                color: #000000;
                padding: 12px 24px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 500;
                transition: all 0.3s ease;
                border: 2px solid #000000;
            }
            .btn-secondary:hover {
                background-color: #000000;
                color: #ffffff;
            }
            .feature-card {
                background-color: #ffffff;
                border: 2px solid #000000;
                border-radius: 12px;
                padding: 24px;
                transition: all 0.3s ease;
            }
            .feature-card:hover {
                background-color: #000000;
                color: #ffffff;
            }
        </style>
    </head>
    <body class="antialiased">
        <!-- Header -->
        <header class="bg-white border-b-2 border-black">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-16">
                    <div class="flex items-center">
                        <img src="{{ asset('images/logo.png') }}" alt="ArtSync" class="h-10 w-auto">
                    </div>
                    
                    @if (Route::has('login'))
                        <div class="flex space-x-4">
                            @auth
                                <a href="{{ url('/dashboard') }}" class="btn-primary">Dashboard</a>
                            @else
                                <a href="{{ route('login') }}" class="btn-secondary">Entrar</a>
                                @if (Route::has('register'))
                                    <a href="{{ route('register') }}" class="btn-primary">Cadastrar</a>
                                @endif
                            @endauth
                        </div>
                    @endif
                </div>
            </div>
        </header>

        <!-- Hero Section -->
        <section class="bg-white py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h1 class="text-5xl font-bold text-black mb-6">
                    Gerencie sua Carreira Artística
                </h1>
                <p class="text-xl text-black mb-8 max-w-3xl mx-auto">
                    O ArtSync é a plataforma gratuita que ajuda artistas iniciantes a organizar, 
                    acompanhar e fazer crescer suas carreiras de forma profissional.
                </p>
                <div class="flex justify-center space-x-4">
                    @guest
                        <a href="{{ route('register') }}" class="btn-primary text-lg px-8 py-4">
                            Começar Gratuitamente
                        </a>
                        <a href="{{ route('login') }}" class="btn-secondary text-lg px-8 py-4">
                            Já tenho conta
                        </a>
                    @else
                        <a href="{{ url('/dashboard') }}" class="btn-primary text-lg px-8 py-4">
                            Ir para Dashboard
                        </a>
                    @endguest
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section class="bg-white py-20 border-t-2 border-black">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-4xl font-bold text-center text-black mb-16">
                    Funcionalidades Principais
                </h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Cadastro e Perfil -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">👤</div>
                        <h3 class="text-xl font-semibold mb-3">Perfil Profissional</h3>
                        <p>Crie seu perfil artístico completo com portfólio, biografia e informações de contato.</p>
                    </div>

                    <!-- Alcance e Métricas -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">📊</div>
                        <h3 class="text-xl font-semibold mb-3">Métricas de Alcance</h3>
                        <p>Acompanhe o crescimento do seu trabalho com relatórios detalhados e análises de desempenho.</p>
                    </div>

                    <!-- Armazenamento -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">📁</div>
                        <h3 class="text-xl font-semibold mb-3">Pasta Pessoal</h3>
                        <p>Organize e armazene seus trabalhos, contratos e documentos importantes em um só lugar.</p>
                    </div>

                    <!-- Notificações -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">🔔</div>
                        <h3 class="text-xl font-semibold mb-3">Notificações</h3>
                        <p>Receba lembretes sobre prazos, oportunidades e atualizações importantes da sua carreira.</p>
                    </div>

                    <!-- Relatórios -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">📄</div>
                        <h3 class="text-xl font-semibold mb-3">Relatórios PDF</h3>
                        <p>Gere relatórios profissionais em PDF para apresentar seu progresso e conquistas.</p>
                    </div>

                    <!-- Busca -->
                    <div class="feature-card">
                        <div class="text-2xl mb-4">🔍</div>
                        <h3 class="text-xl font-semibold mb-3">Busca Avançada</h3>
                        <p>Encontre rapidamente seus trabalhos, contatos e informações com nossa busca inteligente.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="bg-black py-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 class="text-4xl font-bold text-white mb-6">
                    Pronto para Começar?
                </h2>
                <p class="text-xl text-white mb-8 max-w-2xl mx-auto">
                    Junte-se a centenas de artistas que já estão organizando suas carreiras com o ArtSync.
                </p>
                @guest
                    <a href="{{ route('register') }}" class="inline-block bg-white text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all duration-300">
                        Cadastrar Gratuitamente
                    </a>
                @else
                    <a href="{{ url('/dashboard') }}" class="inline-block bg-white text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all duration-300">
                        Acessar Dashboard
                    </a>
                @endguest
            </div>
        </section>

        <!-- Footer -->
        <footer class="bg-white border-t-2 border-black py-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="flex items-center mb-4 md:mb-0">
                        <img src="{{ asset('images/logo.png') }}" alt="ArtSync" class="h-8 w-auto mr-3">
                        <span class="text-lg font-semibold text-black">ArtSync</span>
                    </div>
                    <div class="text-black">
                        <p>&copy; 2025 ArtSync. Todos os direitos reservados.</p>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>

