<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-black leading-tight">
            Dashboard - {{ Auth::user()->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Welcome Section -->
            <div class="bg-white border-2 border-black overflow-hidden shadow-lg sm:rounded-lg mb-6">
                <div class="p-6 text-black">
                    <h3 class="text-2xl font-bold mb-2">Bem-vindo ao ArtSync, {{ Auth::user()->name }}!</h3>
                    <p class="text-gray-700">Gerencie sua carreira artística de forma profissional e organizada.</p>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center hover:bg-black hover:text-white transition-all duration-300">
                    <div class="text-3xl font-bold">0</div>
                    <div class="text-sm">Projetos</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center hover:bg-black hover:text-white transition-all duration-300">
                    <div class="text-3xl font-bold">0</div>
                    <div class="text-sm">Arquivos</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center hover:bg-black hover:text-white transition-all duration-300">
                    <div class="text-3xl font-bold">0</div>
                    <div class="text-sm">Visualizações</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center hover:bg-black hover:text-white transition-all duration-300">
                    <div class="text-3xl font-bold">0</div>
                    <div class="text-sm">Contatos</div>
                </div>
            </div>

            <!-- Main Features Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Tela de Alcance -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">📊</div>
                        <h3 class="text-xl font-semibold">Métricas de Alcance</h3>
                    </div>
                    <p class="mb-4">Acompanhe o desempenho dos seus trabalhos e o crescimento da sua audiência.</p>
                    <a href="{{ route('analytics') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Ver Métricas
                    </a>
                </div>

                <!-- Pasta Pessoal -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">📁</div>
                        <h3 class="text-xl font-semibold">Pasta Pessoal</h3>
                    </div>
                    <p class="mb-4">Organize e armazene seus trabalhos, contratos e documentos importantes.</p>
                    <a href="{{ route('storage') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Acessar Pasta
                    </a>
                </div>

                <!-- Perfil Profissional -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">👤</div>
                        <h3 class="text-xl font-semibold">Perfil Profissional</h3>
                    </div>
                    <p class="mb-4">Complete seu perfil artístico com portfólio e informações profissionais.</p>
                    <a href="{{ route('profile.edit') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Editar Perfil
                    </a>
                </div>

                <!-- Notificações -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">🔔</div>
                        <h3 class="text-xl font-semibold">Notificações</h3>
                    </div>
                    <p class="mb-4">Gerencie lembretes, prazos e atualizações importantes da sua carreira.</p>
                    <a href="{{ route('notifications') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Ver Notificações
                    </a>
                </div>

                <!-- Relatórios -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">📄</div>
                        <h3 class="text-xl font-semibold">Relatórios PDF</h3>
                    </div>
                    <p class="mb-4">Gere relatórios profissionais para apresentar seu progresso e conquistas.</p>
                    <a href="{{ route('reports') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Gerar Relatório
                    </a>
                </div>

                <!-- Busca -->
                <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
                    <div class="flex items-center mb-4">
                        <div class="text-2xl mr-3">🔍</div>
                        <h3 class="text-xl font-semibold">Busca Avançada</h3>
                    </div>
                    <p class="mb-4">Encontre rapidamente seus trabalhos, contatos e informações.</p>
                    <a href="{{ route('search') }}" class="inline-block bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition-colors">
                        Buscar
                    </a>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="mt-8">
                <div class="bg-white border-2 border-black overflow-hidden shadow-lg sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-xl font-semibold text-black mb-4">Atividade Recente</h3>
                        <div class="space-y-3">
                            <div class="flex items-center p-3 bg-gray-50 rounded">
                                <div class="text-sm text-gray-600">Nenhuma atividade recente. Comece explorando as funcionalidades acima!</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

