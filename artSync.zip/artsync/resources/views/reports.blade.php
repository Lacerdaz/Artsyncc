<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-black leading-tight">
                Relatórios PDF
            </h2>
            <button class="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
                + Novo Relatório
            </button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Report Templates -->
            <div class="mb-8">
                <h3 class="text-xl font-semibold text-black mb-4">Modelos de Relatório</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Portfolio Report -->
                    <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all cursor-pointer">
                        <div class="text-3xl mb-4">📊</div>
                        <h4 class="text-lg font-semibold mb-2">Relatório de Portfólio</h4>
                        <p class="text-sm mb-4">Apresentação completa dos seus trabalhos e projetos realizados.</p>
                        <button class="w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition-colors">
                            Gerar Relatório
                        </button>
                    </div>

                    <!-- Performance Report -->
                    <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all cursor-pointer">
                        <div class="text-3xl mb-4">📈</div>
                        <h4 class="text-lg font-semibold mb-2">Relatório de Performance</h4>
                        <p class="text-sm mb-4">Análise detalhada do seu crescimento e métricas de alcance.</p>
                        <button class="w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition-colors">
                            Gerar Relatório
                        </button>
                    </div>

                    <!-- Financial Report -->
                    <div class="bg-white border-2 border-black rounded-lg p-6 hover:bg-black hover:text-white transition-all cursor-pointer">
                        <div class="text-3xl mb-4">💰</div>
                        <h4 class="text-lg font-semibold mb-2">Relatório Financeiro</h4>
                        <p class="text-sm mb-4">Resumo dos seus ganhos, projetos e faturamento mensal.</p>
                        <button class="w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition-colors">
                            Gerar Relatório
                        </button>
                    </div>
                </div>
            </div>

            <!-- Custom Report Builder -->
            <div class="bg-white border-2 border-black rounded-lg p-6 mb-8">
                <h3 class="text-xl font-semibold text-black mb-4">Criar Relatório Personalizado</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Título do Relatório</label>
                        <input type="text" class="w-full border-2 border-black rounded-lg p-3" placeholder="Ex: Relatório Mensal Janeiro 2025">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-black mb-2">Período</label>
                        <select class="w-full border-2 border-black rounded-lg p-3">
                            <option>Último mês</option>
                            <option>Últimos 3 meses</option>
                            <option>Últimos 6 meses</option>
                            <option>Último ano</option>
                            <option>Período personalizado</option>
                        </select>
                    </div>
                </div>

                <div class="mt-6">
                    <label class="block text-sm font-semibold text-black mb-2">Seções a Incluir</label>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Resumo Executivo</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Projetos Realizados</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Métricas de Alcance</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Análise Financeira</span>
                            </label>
                        </div>
                        <div class="space-y-2">
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Feedback dos Clientes</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Comparativo Mensal</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" checked class="mr-3">
                                <span class="text-sm">Metas e Objetivos</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" class="mr-3">
                                <span class="text-sm">Próximos Passos</span>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="mt-6 flex space-x-4">
                    <button class="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                        Gerar Relatório PDF
                    </button>
                    <button class="border-2 border-black text-black px-6 py-3 rounded-lg hover:bg-black hover:text-white transition-all">
                        Visualizar Prévia
                    </button>
                </div>
            </div>

            <!-- Recent Reports -->
            <div class="bg-white border-2 border-black rounded-lg overflow-hidden">
                <div class="bg-gray-50 border-b border-black p-4">
                    <h3 class="text-lg font-semibold text-black">Relatórios Recentes</h3>
                </div>
                
                <div class="divide-y divide-gray-200">
                    <!-- Report Item -->
                    <div class="p-4 hover:bg-gray-50 flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                                <span class="text-red-600 text-lg">📄</span>
                            </div>
                            <div>
                                <h4 class="font-semibold text-black">Relatório de Portfólio - Janeiro 2025</h4>
                                <p class="text-sm text-gray-600">Gerado em 28/01/2025 • 2.3 MB</p>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <!-- Report Item -->
                    <div class="p-4 hover:bg-gray-50 flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                <span class="text-blue-600 text-lg">📊</span>
                            </div>
                            <div>
                                <h4 class="font-semibold text-black">Relatório de Performance - Dezembro 2024</h4>
                                <p class="text-sm text-gray-600">Gerado em 02/01/2025 • 1.8 MB</p>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <!-- Report Item -->
                    <div class="p-4 hover:bg-gray-50 flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                <span class="text-green-600 text-lg">💰</span>
                            </div>
                            <div>
                                <h4 class="font-semibold text-black">Relatório Financeiro - Q4 2024</h4>
                                <p class="text-sm text-gray-600">Gerado em 15/12/2024 • 3.1 MB</p>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                            </button>
                            <button class="text-black hover:text-gray-600 p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Report Statistics -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">15</div>
                    <div class="text-sm text-gray-600">Relatórios Gerados</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">3</div>
                    <div class="text-sm text-gray-600">Este Mês</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">45</div>
                    <div class="text-sm text-gray-600">Downloads</div>
                </div>
                <div class="bg-white border-2 border-black p-6 rounded-lg text-center">
                    <div class="text-3xl font-bold text-black">12.5MB</div>
                    <div class="text-sm text-gray-600">Tamanho Total</div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

