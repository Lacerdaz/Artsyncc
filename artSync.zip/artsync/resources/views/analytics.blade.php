<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-black leading-tight">
            Métricas de Alcance
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Overview Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white border-2 border-black p-6 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Total de Visualizações</p>
                            <p class="text-3xl font-bold text-black">1,234</p>
                        </div>
                        <div class="text-2xl">👁️</div>
                    </div>
                    <p class="text-sm text-green-600 mt-2">+12% este mês</p>
                </div>

                <div class="bg-white border-2 border-black p-6 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Engajamento</p>
                            <p class="text-3xl font-bold text-black">89%</p>
                        </div>
                        <div class="text-2xl">💬</div>
                    </div>
                    <p class="text-sm text-green-600 mt-2">+5% este mês</p>
                </div>

                <div class="bg-white border-2 border-black p-6 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Novos Seguidores</p>
                            <p class="text-3xl font-bold text-black">156</p>
                        </div>
                        <div class="text-2xl">👥</div>
                    </div>
                    <p class="text-sm text-green-600 mt-2">+23% este mês</p>
                </div>

                <div class="bg-white border-2 border-black p-6 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Projetos Ativos</p>
                            <p class="text-3xl font-bold text-black">8</p>
                        </div>
                        <div class="text-2xl">🎨</div>
                    </div>
                    <p class="text-sm text-blue-600 mt-2">2 novos esta semana</p>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <!-- Visualizações por Mês -->
                <div class="bg-white border-2 border-black rounded-lg p-6">
                    <h3 class="text-xl font-semibold text-black mb-4">Visualizações por Mês</h3>
                    <div class="h-64 flex items-end justify-between space-x-2">
                        <div class="bg-black w-8 h-16 rounded-t"></div>
                        <div class="bg-black w-8 h-24 rounded-t"></div>
                        <div class="bg-black w-8 h-32 rounded-t"></div>
                        <div class="bg-black w-8 h-20 rounded-t"></div>
                        <div class="bg-black w-8 h-40 rounded-t"></div>
                        <div class="bg-black w-8 h-48 rounded-t"></div>
                        <div class="bg-black w-8 h-36 rounded-t"></div>
                        <div class="bg-black w-8 h-52 rounded-t"></div>
                        <div class="bg-black w-8 h-44 rounded-t"></div>
                        <div class="bg-black w-8 h-56 rounded-t"></div>
                        <div class="bg-black w-8 h-48 rounded-t"></div>
                        <div class="bg-black w-8 h-60 rounded-t"></div>
                    </div>
                    <div class="flex justify-between text-xs text-gray-600 mt-2">
                        <span>Jan</span>
                        <span>Fev</span>
                        <span>Mar</span>
                        <span>Abr</span>
                        <span>Mai</span>
                        <span>Jun</span>
                        <span>Jul</span>
                        <span>Ago</span>
                        <span>Set</span>
                        <span>Out</span>
                        <span>Nov</span>
                        <span>Dez</span>
                    </div>
                </div>

                <!-- Top Projetos -->
                <div class="bg-white border-2 border-black rounded-lg p-6">
                    <h3 class="text-xl font-semibold text-black mb-4">Projetos Mais Visualizados</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div class="flex items-center">
                                <div class="w-12 h-12 bg-black rounded mr-3"></div>
                                <div>
                                    <p class="font-semibold">Projeto Arte Digital</p>
                                    <p class="text-sm text-gray-600">Ilustração</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-semibold">2,456</p>
                                <p class="text-sm text-gray-600">visualizações</p>
                            </div>
                        </div>

                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div class="flex items-center">
                                <div class="w-12 h-12 bg-black rounded mr-3"></div>
                                <div>
                                    <p class="font-semibold">Série Fotográfica</p>
                                    <p class="text-sm text-gray-600">Fotografia</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-semibold">1,892</p>
                                <p class="text-sm text-gray-600">visualizações</p>
                            </div>
                        </div>

                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div class="flex items-center">
                                <div class="w-12 h-12 bg-black rounded mr-3"></div>
                                <div>
                                    <p class="font-semibold">Pintura Abstrata</p>
                                    <p class="text-sm text-gray-600">Pintura</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-semibold">1,234</p>
                                <p class="text-sm text-gray-600">visualizações</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Audience Insights -->
            <div class="bg-white border-2 border-black rounded-lg p-6 mb-8">
                <h3 class="text-xl font-semibold text-black mb-4">Insights da Audiência</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <h4 class="font-semibold mb-2">Faixa Etária</h4>
                        <div class="space-y-2">
                            <div class="flex justify-between">
                                <span class="text-sm">18-24</span>
                                <span class="text-sm font-semibold">35%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-black h-2 rounded-full" style="width: 35%"></div>
                            </div>
                        </div>
                        <div class="space-y-2 mt-3">
                            <div class="flex justify-between">
                                <span class="text-sm">25-34</span>
                                <span class="text-sm font-semibold">45%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-black h-2 rounded-full" style="width: 45%"></div>
                            </div>
                        </div>
                        <div class="space-y-2 mt-3">
                            <div class="flex justify-between">
                                <span class="text-sm">35+</span>
                                <span class="text-sm font-semibold">20%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-black h-2 rounded-full" style="width: 20%"></div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h4 class="font-semibold mb-2">Localização</h4>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-sm">São Paulo</span>
                                <span class="text-sm font-semibold">28%</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm">Rio de Janeiro</span>
                                <span class="text-sm font-semibold">22%</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm">Belo Horizonte</span>
                                <span class="text-sm font-semibold">15%</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm">Outros</span>
                                <span class="text-sm font-semibold">35%</span>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h4 class="font-semibold mb-2">Dispositivos</h4>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-sm">Mobile</span>
                                <span class="text-sm font-semibold">65%</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm">Desktop</span>
                                <span class="text-sm font-semibold">30%</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm">Tablet</span>
                                <span class="text-sm font-semibold">5%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex space-x-4">
                <button class="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                    Exportar Relatório
                </button>
                <button class="bg-white text-black border-2 border-black px-6 py-3 rounded-lg hover:bg-black hover:text-white transition-all">
                    Configurar Métricas
                </button>
            </div>
        </div>
    </div>
</x-app-layout>

